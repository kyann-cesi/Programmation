﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Runtime;
using System.IO;
using System.Diagnostics;
using System.Media;
using System.Data;
using System.Threading;
using System.Globalization;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;

namespace EasysaveGraph2
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            bool isAlreadyRunning = Process.GetProcessesByName(Process.GetCurrentProcess().ProcessName).Length > 1;

            if (isAlreadyRunning)
            {
                // Ferme le programme si Easysave est déjà lancé
                System.Windows.Forms.MessageBox.Show("Easysave est déjà lancé, vous ne pouvez pas le lancer plus d'une fois.");
                System.Environment.Exit(0);
            }
            Switchlanguage("fr");
        }

        private void Switchlanguage(string languageCode)
        {
            ResourceDictionary dictionary = new ResourceDictionary();
            switch (languageCode)
            {
                case "en":
                    dictionary.Source = new Uri(@"..\Dictionary1.xaml", UriKind.Relative);
                    break;
                case "fr":
                    dictionary.Source = new Uri(@"..\francais.xaml", UriKind.Relative);
                    break;
                default:
                    dictionary.Source = new Uri(@"..\francais.xaml", UriKind.Relative);
                    break;
            }
            this.Resources.MergedDictionaries.Add(dictionary);
        }

        public static void fullBackup(string nomSauvegarde, string formatLogs)
        {
            // Chemin du fichier contenant la liste à crypter
            string extensionsFile = @"C:\Easysave\Profils\" + nomSauvegarde + "_cryptage.txt";
            string priorityFiles = @"C:\Easysave\Profils\" + nomSauvegarde + "_prioritaire.txt";
            string fichierBackup = @"C:\Easysave\Profils\" + nomSauvegarde + ".txt";
            // Chemin du fichier recevant les informations d'avancement de la sauvegarde
            string cheminAvancement = @"C:\Easysave\avancement.txt";
            // Chemin du fichier log
            string cheminLogs = @"C:\Easysave\logs." + formatLogs;
            // Chemin du dossier source
            string dossierSource = File.ReadLines(fichierBackup).Skip(1).Take(1).First();
            // Chemin du dossier cible
            string dossierCible = File.ReadLines(fichierBackup).Skip(2).Take(1).First();


            // Lire le fichier contenant la liste de cryptage
            string[] extensions = File.ReadAllLines(extensionsFile);

            // Lire le fichier contenant la liste prioritaire
            StreamReader Lire1 = new StreamReader(priorityFiles);
            string line1;

            var stopwatch = new Stopwatch(); //début de la stopwatch
            stopwatch.Start();
            long totalBytes = 0;

            if (!Directory.Exists(dossierSource))// Vérifie si les répertoires existent
            {
                Directory.CreateDirectory(dossierSource);
                return;
            }

            if (!Directory.Exists(dossierCible))
            {
                Directory.CreateDirectory(dossierCible);
                return;
            }

            while ((line1 = Lire1.ReadLine()) != null)
            {
                // Parcourir les fichiers du dossier
                foreach (var file in Directory.GetFiles(dossierSource ,"*.*", SearchOption.AllDirectories))
                {
                    if (line1 == Convert.ToString(System.IO.Path.GetExtension(file)))
                    {
                        //if (Array.IndexOf(extensions, System.IO.Path.GetExtension(file)) >= 0)
                        if (extensionsFile.Contains(line1))
                        {
                            // Lancer le processus "cryptosoft" avec le chemin complet du fichier à crypter
                            Process.Start(@"C:\Easysave\cryptosoft\bin\Debug\net6.0\cryptosoft.exe", $"{file} {dossierCible}");
                        }
                        else
                        {
                            // Copier le fichier dans le dossier des fichiers non triés
                            string fileName = System.IO.Path.GetFileName(file);
                            //string destinationFile = dossierCible + fileName;
                            string destinationFile = System.IO.Path.Combine(dossierCible, fileName);
                            var fileInfo = new FileInfo(file);
                            totalBytes += fileInfo.Length;
                            File.Copy(file, destinationFile, true);
                            ecrireFichier(cheminAvancement, DateTime.Now + " Copie du fichier " + destinationFile + " vers " + dossierCible, false);
                        }
                    }
                }
            }

            StreamReader Lire2 = new StreamReader(priorityFiles);
            string line2;

            while ((line2 = Lire2.ReadLine()) != null)
            {
                // Parcourir les fichiers du dossier
                foreach (var file in Directory.GetFiles(dossierSource ,"*.*", SearchOption.AllDirectories))
                {
                    if (line2 != Convert.ToString(System.IO.Path.GetExtension(file)))
                    {
                        if (Array.IndexOf(extensions, System.IO.Path.GetExtension(file)) >= 0)
                        {
                            // Lancer le processus "cryptosoft" avec le chemin complet du fichier à crypter
                            Process.Start(@"C:\Easysave\cryptosoft\bin\Debug\net6.0\cryptosoft.exe", $"{file} {dossierCible}");
                        }
                        else
                        {
                            // Copier le fichier dans le dossier des fichiers non triés
                            string fileName = System.IO.Path.GetFileName(file);
                            //string destinationFile = dossierCible + fileName;
                            string destinationFile = System.IO.Path.Combine(dossierCible, fileName);
                            var fileInfo = new FileInfo(file);
                            totalBytes += fileInfo.Length;
                            File.Copy(file, destinationFile, true);
                            ecrireFichier(cheminAvancement, DateTime.Now + " Copie du fichier " + destinationFile + " vers " + dossierCible, false);
                        }
                    }
                }
            }
            stopwatch.Stop();
            TimeSpan elapsedTime = stopwatch.Elapsed; //fin de stopwatch
            ecrireFichier(cheminLogs, "{", false);
            ecrireFichier(cheminLogs, "Nom : " + nomSauvegarde + ",", false);
            ecrireFichier(cheminLogs, "Dossier source : " + dossierSource + ",", false);
            ecrireFichier(cheminLogs, "Dossier source : " + dossierCible + ",", false);
            ecrireFichier(cheminLogs, "Copie terminée avec succès.", false);
            ecrireFichier(cheminLogs, "Temps écoulé : " + elapsedTime, false);
            ecrireFichier(cheminLogs, "Taille totale des fichiers transférés : " + totalBytes + " octets", false);
            ecrireFichier(cheminLogs, "Vitesse de transfert : " + (totalBytes / 1024 / elapsedTime.TotalSeconds).ToString("0.##") + " Ko/s", false);
            ecrireFichier(cheminLogs, "}", false);
        }
        public static string lireFichier(string cheminFichier)
        {
            StreamReader Lire = new StreamReader(cheminFichier);
            string line;
            string contenuFichier = null;
            while ((line = Lire.ReadLine()) != null)
            {
                contenuFichier += line;
            }
            return contenuFichier;
        }

        public static void ecrireFichier(string cheminFichier, string aEcrire, bool ecraser)
        {
            //la fonction peut être utilisée pour créer un fichier en laissant aEcrire vide
            if (ecraser == false)
            {
                StreamWriter Ecrire = new StreamWriter(cheminFichier, true);
                Ecrire.WriteLine(aEcrire);
                Ecrire.Close();
            }
            else
            {
                StreamWriter Ecrire = new StreamWriter(cheminFichier, false);
                Ecrire.WriteLine(aEcrire);
                Ecrire.Close();
            }
        }
        public static void executeBackup(string cheminProfil, string formatLogs)
        {
            string nomProfil = File.ReadLines(cheminProfil).Skip(0).Take(1).First(); //la 2e ligne du profil est le dossier source
            string cheminAvancement = @"C:\Easysave\avancement.txt";
            string dossierSource = File.ReadLines(cheminProfil).Skip(1).Take(1).First(); //la 2e ligne du profil est le dossier source
            string dossierCible = File.ReadLines(cheminProfil).Skip(2).Take(1).First(); //la 3e ligne du profil est le dossier cible

            string cheminLogs = @"C:\Easysave\logs." + formatLogs;
            if (!Directory.Exists(dossierSource))// Vérifie si les répertoires existent
            {
                Directory.CreateDirectory(dossierSource);
                return;
            }

            if (!Directory.Exists(dossierCible))
            {
                Directory.CreateDirectory(dossierCible);
                return;
            }

            var stopwatch = new Stopwatch(); //début de la stopwatch
            stopwatch.Start();
            long totalBytes = 0;

            /*
            foreach (var file in Directory.GetFiles(dossierSource, "*.*", SearchOption.AllDirectories))
            {
                if (Process.GetProcessesByName("notepad").Length > 0)
                {
                    while(Process.GetProcessesByName("notepad").Length > 0) //tant que notepad est ouvert, boucle
                    {

                    }
                }
                string relativePath = file.Replace(dossierSource, "");
                string targetPath = dossierCible + relativePath;
                Directory.CreateDirectory(System.IO.Path.GetDirectoryName(targetPath));
                var fileInfo = new FileInfo(file);
                totalBytes += fileInfo.Length;
                File.Copy(file, targetPath, true);
                ecrireFichier(cheminAvancement, DateTime.Now + " Copie du fichier " + targetPath + " vers " + dossierCible, false);
            } */
            string priorityFiles = @"C:\Easysave\Profils\" + nomProfil + "_prioritaire.txt";
            StreamReader Lire2 = new StreamReader(priorityFiles);
            string line2;

            while ((line2 = Lire2.ReadLine()) != null) //copie des fichiers prioritaires
            {
                foreach (var file in Directory.GetFiles(dossierSource, "*.*", SearchOption.AllDirectories))
                {
                    if (Process.GetProcessesByName("notepad").Length > 0)
                    {
                        while (Process.GetProcessesByName("notepad").Length > 0) //tant que notepad est ouvert, boucle
                        {

                        }
                    }
                    if (line2 == Convert.ToString(System.IO.Path.GetExtension(file)))
                    {
                        string relativePath = file.Replace(dossierSource, "");
                        string targetPath = dossierCible + relativePath;
                        Directory.CreateDirectory(System.IO.Path.GetDirectoryName(targetPath));
                        var fileInfo = new FileInfo(file);
                        totalBytes += fileInfo.Length;
                        File.Copy(file, targetPath, true);
                        ecrireFichier(cheminAvancement, DateTime.Now + " Copie du fichier prioritaire " + targetPath + " vers " + dossierCible, false);
                    }
                }
            }

            foreach (var file in Directory.GetFiles(dossierSource, "*.*", SearchOption.AllDirectories)) //copie des fichiers non prioritaires
            {
                if (Process.GetProcessesByName("notepad").Length > 0)
                {
                    while(Process.GetProcessesByName("notepad").Length > 0) //tant que notepad est ouvert, boucle
                    {

                    }
                }
                if (File.Exists(dossierCible)) //si le fichier existe déjà dans le dossier cible, ne fais rien
                {

                }
                else //sinon, copie le
                {
                    string relativePath = file.Replace(dossierSource, "");
                    string targetPath = dossierCible + relativePath;
                    Directory.CreateDirectory(System.IO.Path.GetDirectoryName(targetPath));
                    var fileInfo = new FileInfo(file);
                    totalBytes += fileInfo.Length;
                    File.Copy(file, targetPath, true);
                    ecrireFichier(cheminAvancement, DateTime.Now + " Copie du fichier " + targetPath + " vers " + dossierCible, false);
                }
            }

            stopwatch.Stop();
            TimeSpan elapsedTime = stopwatch.Elapsed; //fin de stopwatch

            ecrireFichier(cheminLogs, "{", false);
            ecrireFichier(cheminLogs, "Nom : " + nomProfil + ",", false);
            ecrireFichier(cheminLogs, "Dossier source : " + dossierSource + ",", false);
            ecrireFichier(cheminLogs, "Dossier source : " + dossierCible + ",", false);
            ecrireFichier(cheminLogs, "Copie terminée avec succès.", false);
            ecrireFichier(cheminLogs, "Temps écoulé : " + elapsedTime, false);
            ecrireFichier(cheminLogs, "Taille totale des fichiers transférés : " + totalBytes + " octets", false);
            ecrireFichier(cheminLogs, "Vitesse de transfert : " + (totalBytes / 1024 / elapsedTime.TotalSeconds).ToString("0.##") + " Ko/s", false);
            ecrireFichier(cheminLogs, "}", false);
        }
        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Form2 addSaveProfile = new Form2();
            addSaveProfile.Show();
        }

        private void ComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            
        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_2(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click2(object sender, RoutedEventArgs e)
        {
            Form3 executeBackup = new Form3();
            executeBackup.Show();
        }

        private void Create_Encryption(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Form1 settings = new Form1();
            settings.Show();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            Switchlanguage("fr");
        }
        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            Switchlanguage("en");
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {

        }
    }
}
