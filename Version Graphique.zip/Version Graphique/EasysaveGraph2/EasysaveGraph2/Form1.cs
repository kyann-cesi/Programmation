﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace EasysaveGraph2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedItem)
            {
                case "Français":
                    Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("français");
                    break;

                case "Anglais":
                    Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("anglais");
                    break;
            }

            this.Controls.Clear();
            InitializeComponent();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            StreamReader Lire = new StreamReader(@"C:\Easysave\logs.json"/* + formatLogs*/);
            string line;
            string contenu = "";
            while ((line = Lire.ReadLine()) != null)
            {
                contenu += (line + "\r\n");
            }
            textBox1.Text = contenu;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("explorer.exe", @"C:\Easysave");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
