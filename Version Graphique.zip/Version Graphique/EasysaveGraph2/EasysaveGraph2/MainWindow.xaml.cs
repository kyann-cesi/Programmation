﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Runtime;
using System.IO;
using System.Diagnostics;
using System.Media;
using System.Data;
using System.Threading;
using System.Globalization;

namespace EasysaveGraph2
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {

        }
        public static string lireFichier(string cheminFichier)
        {
            StreamReader Lire = new StreamReader(cheminFichier);
            string line;
            string contenuFichier = null;
            while ((line = Lire.ReadLine()) != null)
            {
                contenuFichier += line;
            }
            return contenuFichier;
        }

        public static void ecrireFichier(string cheminFichier, string aEcrire, bool ecraser)
        {
            //la fonction peut être utilisée pour créer un fichier en laissant aEcrire vide
            if (ecraser == false)
            {
                StreamWriter Ecrire = new StreamWriter(cheminFichier, true);
                Ecrire.WriteLine(aEcrire);
                Ecrire.Close();
            }
            else
            {
                StreamWriter Ecrire = new StreamWriter(cheminFichier, false);
                Ecrire.WriteLine(aEcrire);
                Ecrire.Close();
            }
        }
        public static void multiBackup(string cheminFichier, string formatLogs) //prends en paramètre un fichier contenant une liste de backup à exécuter
        {
            StreamReader Lire = new StreamReader(cheminFichier);
            string line;
            while ((line = Lire.ReadLine()) != null)
            {
                executeBackup(@"C:\Easysave\Profils\" + line + ".txt", formatLogs);
            }
            Lire.Close();
        }
        public static void executeBackup(string cheminProfil, string formatLogs)
        {
            string nomProfil = File.ReadLines(cheminProfil).Skip(0).Take(1).First(); //la 2e ligne du profil est le dossier source
            string cheminAvancement = @"C:\Easysave\avancement.txt";
            string dossierSource = File.ReadLines(cheminProfil).Skip(1).Take(1).First(); //la 2e ligne du profil est le dossier source
            string dossierCible = File.ReadLines(cheminProfil).Skip(2).Take(1).First(); //la 3e ligne du profil est le dossier cible

            string cheminLogs = @"C:\Easysave\logs." + formatLogs;
            if (!Directory.Exists(dossierSource))// Vérifie si les répertoires existent
            {
                Directory.CreateDirectory(dossierSource);
                return;
            }

            if (!Directory.Exists(dossierCible))
            {
                Directory.CreateDirectory(dossierCible);
                return;
            }

            var stopwatch = new Stopwatch(); //début de la stopwatch
            stopwatch.Start();
            long totalBytes = 0;

            foreach (var file in Directory.GetFiles(dossierSource, "*.*", SearchOption.AllDirectories))
            {
                string relativePath = file.Replace(dossierSource, "");
                string targetPath = dossierCible + relativePath;
                Directory.CreateDirectory(System.IO.Path.GetDirectoryName(targetPath));
                var fileInfo = new FileInfo(file);
                totalBytes += fileInfo.Length;
                File.Copy(file, targetPath, true);
                ecrireFichier(cheminAvancement, DateTime.Now + " Copie du fichier " + targetPath + " vers " + dossierCible, false);
            }

            stopwatch.Stop();
            TimeSpan elapsedTime = stopwatch.Elapsed; //fin de stopwatch

            ecrireFichier(cheminLogs, "{", false);
            ecrireFichier(cheminLogs, "Nom : " + nomProfil + ",", false);
            ecrireFichier(cheminLogs, "Dossier source : " + dossierSource + ",", false);
            ecrireFichier(cheminLogs, "Dossier source : " + dossierCible + ",", false);
            ecrireFichier(cheminLogs, "Copie terminée avec succès.", false);
            ecrireFichier(cheminLogs, "Temps écoulé : " + elapsedTime, false);
            ecrireFichier(cheminLogs, "Taille totale des fichiers transférés : " + totalBytes + " octets", false);
            ecrireFichier(cheminLogs, "Vitesse de transfert : " + (totalBytes / 1024 / elapsedTime.TotalSeconds).ToString("0.##") + " Ko/s", false);
            ecrireFichier(cheminLogs, "}", false);
        }
        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Form2 addSaveProfile = new Form2();
            addSaveProfile.Show();
        }

        private void ComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            
        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_2(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click2(object sender, RoutedEventArgs e)
        {
            Form3 executeBackup = new Form3();
            executeBackup.Show();
        }

        private void Create_Encryption(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Form1 settings = new Form1();
            settings.Show();
        }
    }
}
