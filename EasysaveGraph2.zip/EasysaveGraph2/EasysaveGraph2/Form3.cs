﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Media;
using System.Diagnostics;

namespace EasysaveGraph2
{
    public partial class Form3 : Form
    {

        public Form3()
        {
            InitializeComponent();
            StreamReader reader = new StreamReader(@"C:\Easysave\Profils\listeprofils.txt");
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                checkedListBox1.Items.Add(line);
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        public void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        private void checkedListBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Process process = new Process("notepad");
            if (Process.GetProcessesByName("notepad").Length>0)
            {
                MessageBox.Show("Le bloc-note doit être fermé pour exécuter une sauvegarde. Fermez le bloc-note puis réessayez.", "Attention", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                foreach (var item in checkedListBox1.CheckedItems)
                {
                    string nomProfil = Convert.ToString(item);
                    MainWindow.fullBackup(nomProfil, "json");
                }
                this.Close();
            }
        }
    }
}
